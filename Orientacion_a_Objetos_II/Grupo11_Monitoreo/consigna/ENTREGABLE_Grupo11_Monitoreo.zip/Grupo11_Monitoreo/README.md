# TP integrador — Monitoreo ambiental

## Requisitos

Registrar sensores con nombre, ubicación, temperatura y humedad; consultar y modificar mediciones; notificar automáticamente a dos observadores; seleccionar e intercambiar estrategias de temperatura y humedad; mostrar los resultados. Observer y Strategy forman parte del mismo sistema.

## Contenido de la entrega

- `main.py` y `monitoreo.py`: código fuente de la aplicación.
- `diagramas/clases.pdf`: clases y relaciones.
- `diagramas/secuencia.pdf`: modificación de temperatura, notificación y evaluación.
- `diagramas/estados.pdf`: estados y transiciones del sensor.
- Este README: requisitos, ejecución y explicación de los patrones.

## Ejecutar

Requiere Python 3.10 o superior, sin paquetes adicionales. Abrir una terminal en esta carpeta:

```sh
python3 -B main.py --demo
python3 -B main.py
```

En Windows se puede usar `py -3` en lugar de `python3`.

La primera orden ejecuta una demostración automática. La segunda abre el menú para registrar y consultar sensores, cambiar mediciones, seleccionar estrategias y agregar observadores. `0` sale.

## Observer

`Sensor` mantiene una colección de objetos que cumplen el contrato `Observador`. Después de guardar nuevas mediciones, llama automáticamente a `actualizar` en cada uno. Operador y Supervisor son dos instancias distintas de `ObservadorConsola`. Se pueden registrar más receptores sin cambiar la lógica del sensor.

## Strategy

`Sensor` conserva una `EstrategiaEvaluacion` y delega en ella la evaluación de sus mediciones. `EvaluacionTemperatura` y `EvaluacionHumedad` implementan el mismo contrato con criterios diferentes. La estrategia se reemplaza durante la ejecución y reevalúa los datos actuales sin crear otro sensor.

## Integración y ejemplo

Un cambio de mediciones sigue este orden: **validar y guardar → notificar con Observer → evaluar con Strategy → actualizar estado**. Cambiar solo la estrategia reevalúa sin notificar un cambio de medición.

La demo inicia en 22 °C y 45 %. Al subir a 31 °C avisa a ambos observadores y genera alerta por temperatura. Al elegir humedad vuelve a normal. Con 75 % genera alerta por humedad y con 60 % vuelve a normal.

Los umbrales de ejemplo son temperatura >30 °C y humedad >70 %. El sensor pasa entre Configurado, Monitoreando y Alerta generada. Los datos se conservan en memoria durante la ejecución.
